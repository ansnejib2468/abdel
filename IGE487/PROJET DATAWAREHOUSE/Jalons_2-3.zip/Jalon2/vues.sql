-----------Creation des vues-----------------------

--1--une vue pour Client_date pour avoir accés seulement aux clients qui ont effectué des reservations le 'date':

CREATE VIEW Client_date AS
SELECT Client.idClient, Client.NOM, Client.Prenom, Client.Adresse, Client.Sexe, Client.Courriel, Client.Tel
FROM Client, Reservation
WHERE Client.idClient= Reservation.idClient AND DateReservationT='date';


--2-- une vue qui donne pour chaque complexe, le nombre des terrains qui ont été réservé  'une date':

CREATE VIEW NBT_complexe AS
SELECT CentreSportif.idCentre, CentreSportif.Nom, CentreSportif.Adresse, COUNT(Distinct idTerrain)
FROM CentreSportif, Reservation
WHERE CentreSportif.idCentre=Reservation.idCentre AND dateReservationT='date'
GROUP BY CentreSportif.idCentre;

--3-- une vue qui donne pour chaque complexe les terrains disponibles:

CREATE T_complexe_date AS
SELECT CentreSportif.idCentre, CentreSportif.Nom, Terrain.idTerrain
FROM CentreSportif, Terrain, Reservation
WHERE CentreSportif.idCentre=Terrain.idCentre AND Disponible=TRUE
GROUP BY CentreSportif.idCentre;

