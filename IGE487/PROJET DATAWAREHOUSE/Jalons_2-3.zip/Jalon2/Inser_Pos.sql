/*
-- =========================================================================== A
-- Composant Insertion_pos.sql
-- -----------------------------------------------------------------------------
Activité : IGE 487
Trimestre : 2018-3
Encodage : UTF-8, sans BOM; fin de ligne Unix (LF)
Plateforme : PostgreSQL 9.6 à 10.5
Responsable : Luc.Lavoie@USherbrooke.ca
Version : 0.1.0a
Statut : en développement
-- =========================================================================== A
*/

/*
-- =========================================================================== B
Toutes les insertions de ce fichier sont valides et doivent être acceptées.
Pour plus d'information, voir ReflexD_cre.sql
-- =========================================================================== B
*/

--
-- Client : données VALIDES
--
INSERT INTO client(idclient, nom, prenom, sexe, adresse, courriel, tel) VALUES
  ('CL000001', 'Dana' , 'Volpe', 'F', '1178 Toy Avenue Oshawa, ON L1H 1A8' , 'Dana.Volpe@yopmail.com' , '8195775069'),
  ('CL000002', 'Eva' , 'Bryant', 'F', '1749 Wellington Ave Chilliwack, BC V2P 2M1' , 'Eva.Bryant@yopmail.com' , '8193659875'),
  ('CL000003', 'Golden' , 'Brandy', 'M', '1749 Wellington Ave Chilliwack, BC V2P 2M1' , 'Golden.Brandy@yopmail.com' ,'8193452569'),
  ('CL000004', 'Boss' , 'Leona', 'F', '1905 Birkett Lane Brantford, ON N3T 2Z8' , 'Boss.Leona@yopmail.com' , '8194795239'),
  ('CL000005', 'Shirley ' , 'Weber', 'M', '2797 rue Garneau Quebec, QC G1V 3V5' , 'Shirley.Weber@yopmail.com' , '8194395989')
  ;
--
-- Centre Sportif : données VALIDES
--
INSERT INTO centresportif(idcentre, nom, Polyvalent, nbterrain, adresse, courriel, tel) VALUES
  ('CSP00001', 'Pacifique', true, 3, '158,rue de Sherbrooke', 'Dana.Volpe@yopmail.com', 8195775069),
  ('CSP00002', 'UdeS', true, 5, '10,rue de Amherst', 'Eva.Bryant@yopmail.com', 8193659875),
  ('CSP00003', 'Calgary',true, 7, '3,rue de Amiral', 'Eva.Bryant@yopmail.com', 8193659875),
  ('CSP00004', 'Atlantique', true, 2, '20,rue du Baron', 'Golden.Brandy@yopmail.com', 8193452569),
  ('CSP00005', 'Manitoba', false, 4, '19,rue du Dauphin', 'Boss.Leona@yopmail.com', 8194795239)
  ;
--
-- Sports : données VALIDES
--
INSERT INTO Sport(idsport, nom) VALUES
  ('SPT001', 'Football'),
  ('SPT002', 'Handball'),
  ('SPT003', 'Tennis'),
  ('SPT004', 'Basketball'),
  ('SPT005', 'Golf'),
  ('SPT006', 'Baseball'),
  ('SPT007', 'Hockey')
  ;
--
-- Accueille: données VALIDES
--
INSERT INTO estpratique(idCentre, idSport) VALUES

('CSP00001', 'SPT001'),
('CSP00001', 'SPT002'),
('CSP00001', 'SPT003'),
('CSP00001', 'SPT004'),
('CSP00001', 'SPT005'),
('CSP00001', 'SPT006'),
('CSP00002', 'SPT001'),
('CSP00002', 'SPT002'),
('CSP00002', 'SPT003'),
('CSP00002', 'SPT004'),
('CSP00002', 'SPT005'),
('CSP00002', 'SPT006'),
('CSP00003', 'SPT005'),
('CSP00003', 'SPT007'),
('CSP00004', 'SPT001'),
('CSP00004', 'SPT002'),
('CSP00004', 'SPT003'),
('CSP00004', 'SPT004'),
('CSP00004', 'SPT005'),
('CSP00004', 'SPT006'),
('CSP00005', 'SPT004')

;
--
-- Terrain: données VALIDES
--
INSERT INTO Terrain(idTerrain, idCentre, Disponible) VALUES
('TR0001', 'CSP00001',  True),
('TR0002', 'CSP00002',  True),
('TR0003', 'CSP00004',  False),
('TR0004', 'CSP00003',  True),
('TR0005', 'CSP00001',  True),
('TR0006', 'CSP00002',  False),
('TR0007', 'CSP00005',  True),
('TR0008', 'CSP00002',  False),
('TR0009', 'CSP00001',  True),
('TR0010', 'CSP00004',  False),
('TR0011', 'CSP00005',  True),
('TR0012', 'CSP00003',  True)

;
--
-- Peut acceuille : données VALIDES
--
INSERT INTO accueille(idTerrain, idcentre, idSport) VALUES
  ('TR0001', 'CSP00001' , 'SPT001'),
  ('TR0001', 'CSP00001' , 'SPT002'),
  ('TR0001', 'CSP00001' , 'SPT003'),
  ('TR0002', 'CSP00002' , 'SPT001'),
  ('TR0003', 'CSP00004' , 'SPT001'),
  ('TR0003', 'CSP00004' , 'SPT006'),
  ('TR0003', 'CSP00004' , 'SPT003'),
  ('TR0003', 'CSP00004' , 'SPT002'),
  ('TR0005', 'CSP00001' , 'SPT004'),
  ('TR0006', 'CSP00002' , 'SPT004'),
  ('TR0008', 'CSP00002' , 'SPT001'),
  ('TR0009', 'CSP00001' , 'SPT002'),
  ('TR0010', 'CSP00004' , 'SPT003'),
  ('TR0009', 'CSP00001' , 'SPT001'),
  ('TR0012', 'CSP00003' , 'SPT007')
;
--
-- Attribue Equipement: données VALIDES
--
INSERT INTO typeequipement(idtypeequipement, idsport, nom) VALUES
  ('TE0001', 'SPT001', 'Ballon de Football' ),
  ('TE0002', 'SPT004', 'Ballon de Basketball' ),
  ('TE0003', 'SPT006', 'Balle de Baseball' ),
  ('TE0004', 'SPT006', 'Batte de Baseball' ),
  ('TE0005', 'SPT003', 'Balle de Tennis' ),
  ('TE0006', 'SPT003', 'Raquette de Tennis' ),
  ('TE0007', 'SPT005', 'Balle de Golf' ),
  ('TE0008', 'SPT005', 'Club de Golf' ),
  ('TE0009', 'SPT007', 'Crosse de Hockey' ),
  ('TE0010', 'SPT007', 'Palet de Hockey' ),
  ('TE0011', 'SPT002', 'Ballon de Handball' )
;

--
-- Equipement: données VALIDES
--
INSERT INTO Equipement(idEquipement, idCentre, idtypeequipement, disponible) VALUES
('EQ0001', 'CSP00001', 'TE0001', true ),
('EQ0002', 'CSP00001', 'TE0002', true ),
('EQ0003', 'CSP00001', 'TE0003', true ),
('EQ0004', 'CSP00001', 'TE0004', true ),
('EQ0005', 'CSP00001', 'TE0001', true ),
('EQ0006', 'CSP00001', 'TE0005', true ),

('EQ0007', 'CSP00002', 'TE0005', true ),
('EQ0008', 'CSP00002', 'TE0004', true ),
('EQ0009', 'CSP00002', 'TE0001', true ),
('EQ0010', 'CSP00002', 'TE0002', true ),
('EQ0011', 'CSP00002', 'TE0005', false ),
('EQ0012', 'CSP00002', 'TE0003', true ),

('EQ0013', 'CSP00003', 'TE0005', false ),
('EQ0014', 'CSP00003', 'TE0004', true ),
('EQ0015', 'CSP00003', 'TE0002', true ),
('EQ0016', 'CSP00003', 'TE0001', true ),
('EQ0017', 'CSP00003', 'TE0005', true ),
('EQ0018', 'CSP00003', 'TE0003', true ),

('EQ0019', 'CSP00004', 'TE0005', true ),

('EQ0020', 'CSP00005', 'TE0001', true )

;
--
-- Vestiaire : données VALIDES
--
INSERT INTO Vestiaire(idVestiaire, idCentre, sexe, capacite, disponible) VALUES
('VST001', 'CSP00001', 'F', 20, true),
('VST002', 'CSP00001', 'M', 15, true),
('VST003', 'CSP00001', 'M', 12, true),
('VST004', 'CSP00001', 'F', 22, true),
('VST005', 'CSP00001', 'F', 15, true),
('VST006', 'CSP00001', 'M', 15, true),

('VST007', 'CSP00002', 'F', 40, true),
('VST008', 'CSP00002', 'F', 50, true),
('VST009', 'CSP00002', 'F', 45, true),
('VST010', 'CSP00002', 'M', 30, false),
('VST011', 'CSP00002', 'F', 25, true),
('VST012', 'CSP00002', 'M', 50, true),

('VST013', 'CSP00003', 'F', 20, true),
('VST014', 'CSP00003', 'M', 25, true),
('VST015', 'CSP00003', 'M', 40, false),
('VST016', 'CSP00003', 'M', 32, true),
('VST017', 'CSP00003', 'F', 47, true),
('VST018', 'CSP00003', 'F', 26, true),

('VST019', 'CSP00004', 'F', 27, true),
('VST020', 'CSP00004', 'M', 31, true),
('VST021', 'CSP00004', 'M', 22, true),

('VST022', 'CSP00005', 'M', 41, true),
('VST023', 'CSP00005', 'M', 60, true),
('VST024', 'CSP00005', 'M', 62, true)
;
--
-- Evenement : données VALIDES
--
INSERT INTO evenement(idevenement, idclient, debutevenement, finevenement, description) VALUES
('E0000001', 'CL000001', '2018-03-02 10:00:00' , '2018-03-05 12:00:00', 'Tournois de Football'),
('E0000002', 'CL000002', '2018-03-02 10:00:00' , '2018-03-05 12:00:00', 'Tournois de Golf'),
('E0000003', 'CL000003', '2018-03-02 10:00:00' , '2018-03-05 12:00:00', 'Tournois de Hockey'),
('E0000004', 'CL000004', '2018-03-02 10:00:00' , '2018-03-05 12:00:00', 'Tournois de Tennis'),
('E0000005', 'CL000005', '2018-03-02 10:00:00' , '2018-03-05 12:00:00', 'Tournois de Football'),
('E0000006', 'CL000001', '2018-03-02 10:00:00' , '2018-03-05 12:00:00', 'Tournois de Basketball'),
('E0000007', 'CL000002', '2018-03-02 10:00:00' , '2018-03-05 12:00:00', 'Tournois de Baseball'),
('E0000008', 'CL000004', '2018-03-02 10:00:00' , '2018-03-05 12:00:00', 'Tournois de Golf'),
('E0000009', 'CL000003', '2018-03-02 10:00:00' , '2018-03-05 12:00:00', 'Tournois de handball')

;

--
-- Reservation : données VALIDES
--
('TR0010', 'CSP00004' , 'SPT003'),


INSERT INTO Reservation(idReservation ,idClient, idevenement, debutreservation, finreservation, idcentre, idterrain, idsport, date_reservation) VALUES
('RZ000001','CL000001', 'E0000006', '2018-03-02 10:00:00' , '2018-03-05 12:00:00', 'CSP00001' , 'TR0001', 'SPT001',  '1996-01-24'),
INSERT INTO Reservation(idReservation ,idClient, idevenement, debutreservation, finreservation, idcentre, idterrain, idsport, date_reservation) VALUES
('RZ000006','CL000004', 'E0000004', '2018-03-02 10:00:00' , '2018-03-05 12:00:00', 'CSP00004' , 'TR0010', 'SPT003',  '1996-01-24')

--
-- Attribue Vestiaire: données VALIDES
--
INSERT INTO attribuevestiaire( idReservation, debutreservation, finreservation,  idcentre, idvestiaire, dateréservationv, sexevestiaire) VALUES
('RZ000001', '2018-03-02 10:00:00' , '2018-03-05 12:00:00',  'CSP00001', 'VST001', '2018-03-01 12:00:00', 'M');



INSERT INTO attribueequipement(idReservation, debutreservation, finreservation, idcentre, idEquipement, dateréservatione) VALUES
('RZ000001', '2018-03-02 10:00:00' , '2018-03-05 12:00:00',  'CSP00001', 'EQ0001', '2018-03-01 12:00:00');



INSERT INTO attribuevestiaire( idReservation, debutreservation, finreservation,  idcentre, idvestiaire, dateréservationv, sexevestiaire) VALUES
('RZ000001', '2018-03-02 10:00:00' , '2018-03-05 12:00:00',  'CSP00002', 'VST010', '2018-03-01 12:00:00', 'M');

--
-- Attribue Equipement: données VALIDES
--


/*
-- =========================================================================== Z
Contributeurs :
  (NO) nora.outkhamou@USherbrooke.ca,
  (AS) soua3004@USherbrooke.ca,
  (SZ) Sara.Zenibi@USherbrooke.ca
  (SZ) loup.Fauries@USherbrooke.ca



Adresse, droits d'auteur et copyright :
  Groupe Metis
  Département d'informatique
  Faculté des sciences
  Université de Sherbrooke
  Sherbrooke (Québec)  J1K 2R1
  Canada
  http://info.usherbrooke.ca/llavoie/
  [CC BY-4.0 (http://creativecommons.org/licenses/by/4.0)]


Références :
[eno] http://info.usherbrooke.ca/llavoie/enseignement/Exemples/ReflexD/ReflexD_DDV.pdf
-- -----------------------------------------------------------------------------
-- fin de Insertion_pos.sql
-- =========================================================================== Z
*/
