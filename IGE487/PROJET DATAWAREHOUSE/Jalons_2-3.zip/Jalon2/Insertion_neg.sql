/*
-- =========================================================================== A
-- Composant Insertion_neg.sql
-- -----------------------------------------------------------------------------
Activité : IGE 487
Trimestre : 2018-3
Encodage : UTF-8, sans BOM; fin de ligne Unix (LF)
Plateforme : PostgreSQL 9.6 à 10.5
Responsable : Luc.Lavoie@USherbrooke.ca
Version : 0.2.0a
Statut : en développement
-- =========================================================================== A
*/

/*
-- =========================================================================== B
Toutes les insertions de ce fichier sont invalides et doivent être refusées.
Pour plus d'information, voir ReflexD_cre.sql
-- =========================================================================== B
*/

--
-- Client : données INVALIDES
--
INSERT INTO client(idclient, nom, adresse, tel)
  VALUES -- idclient invalide sans la lettre P au debut
  ('001',  'Pierre', '35,rue Cabana',  '8195775069');
INSERT INTO client(idclient, nom, adresse, tel)
  VALUES -- idclient tres long
  ('P16541234511',  'Pierre', '35,rue Cabana',  '8195775069');
INSERT INTO client(idclient, nom, adresse, tel)
  VALUES -- Num Telephone depasse 10
  ('P001',  'Pierre', '35,rue Cabana',  '819577506954654');
INSERT INTO client(idclient, nom, adresse, tel)
  VALUES -- idclient existe déjà
  ('P001',  'Pierre', '35,rue Cabana',  '8195775069');

--
-- Centre Sportif : données INVALIDES
--
INSERT INTO centresportif(idcentre, nom, Adresse, Tel, Polyvalent, nombreMaxTerrain)
  VALUES -- idCentre sans la lettre C au debut
  ('001', 'Pacifique','158,rue de Sherbrooke', '8194578923',True,10);
INSERT INTO centresportif(idcentre, nom, Adresse, Tel, Polyvalent, nombreMaxTerrain)
  VALUES -- idCentre tres long
  ('C654651245879', 'Pacifique','158,rue de Sherbrooke', '8194578923',True,10);
INSERT INTO centresportif(idcentre, nom, Adresse, Tel, Polyvalent, nombreMaxTerrain)
  VALUES -- idCentre tres court
  ('C5', 'Pacifique','158,rue de Sherbrooke', '8194578923',True,10);
INSERT INTO centresportif(idcentre, nom, Adresse, Tel, Polyvalent, nombreMaxTerrain)
  VALUES -- idCentre existe déjà
  ('C001', 'Pacifique','158,rue de Sherbrooke', '8194578923',True,10);

--
-- Sports : données INVALIDES
--
INSERT INTO Sports(idsport, nom)
  VALUES  -- idSport tres long
  ('SPT06476812', 'Football');
INSERT INTO Sports(idsport, nom)
  VALUES  -- idSport tres court
  ('SPT2', 'Football');
INSERT INTO Sports(idsport, nom)
  VALUES  -- tuple existe déjà
  ('SPT001', 'Football');

--
-- Accueille: données INVALIDES
--
INSERT INTO accueille(idCentre, idSport)
    VALUES -- idCentre se trouve pas dans la table centre sportif
  ('C008', 'SPT001');

INSERT INTO accueille(idCentre, idSport)
    VALUES -- tuple existe déjà
  ('C001', 'SPT001');

INSERT INTO accueille(idCentre, idSport)
    VALUES -- idSport se trouve pas dans la table centre sportif
  ('C001', 'SPT010');


--
-- Terrain: données INVALIDES
--
INSERT INTO Terrain(idTerrain, idCentre,Disponible)
  VALUES  -- idTerrain ne respecte pas la forme de son domaine
 ('Ter21', 'C001',  True);


INSERT INTO Terrain(idTerrain, idCentre,Disponible)
  VALUES  -- idCentre n'existe pas dans la table centre sportif
 ('TR001', 'C009',  True);


--
-- Peut Abritert : données INVALIDES
--
INSERT INTO PeutAbriter(idTerrain, idSport)
  VALUES -- idTrrain n'existe pas dans la table Terrain
  ('TR030', 'SPT001');

INSERT INTO PeutAbriter(idTerrain, idSport)
  VALUES -- idSport ne respecte pas la forme de son domaine
  ('TR001', 'SPT00654');



---
-- Equipement: données INVALIDES
--
INSERT INTO Equipement(idEquipement, nom, idCentre,quantité,idSport)
   VALUES -- idEquipement ne respect pas la forme de son domaine
  ('Equi1', 'Ballon de Basket', 'C001',5,'SPT004');


INSERT INTO Equipement(idEquipement, nom, idCentre,quantité,idSport)
   VALUES -- tuple existe déjà
  ('EQ001', 'Ballon de Basket', 'C001',5,'SPT004');

INSERT INTO Equipement(idEquipement, nom, idCentre,quantité,idSport)
   VALUES -- idEquipement invalid --> tres court
  ('EQ1', 'Ballon de Basket', 'C001',5,'SPT004');

INSERT INTO Equipement(idEquipement, nom, idCentre,quantité,idSport)
   VALUES -- idEquipement invalid --> tres long
  ('EQ000001', 'Ballon de Basket', 'C001',5,'SPT004');

--
-- Vestiaire : données INVALIDES
--
INSERT INTO Vestiaire(idVestiaire, idCentre, capacite)
    VALUES -- idVestiaire ne commence pas par VST
  ('V001', 'C001', 20);

INSERT INTO Vestiaire(idVestiaire, idCentre, capacite)
    VALUES -- idVestiaire tres court
  ('VST1', 'C001', 20);

INSERT INTO Vestiaire(idVestiaire, idCentre, capacite)
    VALUES -- tuple existe déjà
  ('VST001', 'C001', 20);
--
-- Reservation : données INVALIDES
--
INSERT INTO Reservation(idClient, idTerrain, dateDebut, dateFin, HeureDebut,HeureFin,TypeReservation,Description,Date_reservation)
    VALUES -- idClient n'existe pas
  ('P008', 'TR001', '2018-03-02','2018-03-05','10:00','12:00', 'AMICAL', 'Un groupe d individus qui veulent faire un match','2018-03-01');


INSERT INTO Reservation(idClient, idTerrain, dateDebut, dateFin, HeureDebut,HeureFin,TypeReservation,Description,Date_reservation)
    VALUES -- HeureFin < HeureDebut
  ('P001', 'TR001', '2018-03-05','2018-03-02','12:00','10:00', 'AMICAL', 'Un groupe d individus qui veulent faire un match','2018-03-01');

INSERT INTO Reservation(idClient, idTerrain, dateDebut, dateFin, HeureDebut,HeureFin,TypeReservation,Description,Date_reservation)
    VALUES -- Tuple existe déjà
  ('P001', 'TR001', '2018-03-02','2018-03-05','10:00','12:00', 'AMICAL', 'Un groupe d individus qui veulent faire un match','2018-03-01');


--
-- Attribue Vestiaire: données INVALIDES
--
INSERT INTO attribuevestiare(idClient, idTerrain, dateDebut, dateFin, HeureDebut,HeureFin,idVestiaire,nombre_vestiaire)
   VALUES -- tuple existe déjà
  ('P001', 'TR001', '2018-03-02','2018-03-05','10:00','12:00','VST006',1);

INSERT INTO attribuevestiare(idClient, idTerrain, dateDebut, dateFin, HeureDebut,HeureFin,idVestiaire,nombre_vestiaire)
   VALUES -- dateDebut > dateFin
  ('P001', 'TR001', '2018-03-09','2018-03-05','10:00','12:00','VST006',1);


INSERT INTO attribuevestiare(idClient, idTerrain, dateDebut, dateFin, HeureDebut,HeureFin,idVestiaire,nombre_vestiaire)
   VALUES -- HeureFin < HeureDebut
  ('P001', 'TR001', '2018-03-02','2018-03-05','14:00','12:00','VST006',1);


--
-- Attribue Equipement: données INVALIDES
--
INSERT INTO AttribueEquipement(idClient, idTerrain, dateDebut, dateFin, HeureDebut,HeureFin,idEquipement, quantite_Equipement)
    VALUES -- tuple existe déjà
  ('P001', 'TR001', '2018-03-02','2018-03-05','10:00','12:00','EQ006',5);

INSERT INTO AttribueEquipement(idClient, idTerrain, dateDebut, dateFin, HeureDebut,HeureFin,idEquipement, quantite_Equipement)
    VALUES -- dateDebut > dateFin
  ('P001', 'TR001', '2018-03-07','2018-03-05','10:00','12:00','EQ006',5);

INSERT INTO AttribueEquipement(idClient, idTerrain, dateDebut, dateFin, HeureDebut,HeureFin,idEquipement, quantite_Equipement)
    VALUES -- HeureFin < HeureDebut
  ('P001', 'TR001', '2018-03-02','2018-03-05','18:00','12:00','EQ006',5);


/*
-- =========================================================================== Z
Contributeurs :
   (NO) nora.outkhamou@USherbrooke.ca,
  (AS) soua3004@USherbrooke.ca,
  (SZ) Sara.Zenibi@USherbrooke.ca
  (SZ) loup.Fauries@USherbrooke.ca

Adresse, droits d'auteur et copyright :
  Groupe Metis
  Département d'informatique
  Faculté des sciences
  Université de Sherbrooke
  Sherbrooke (Québec)  J1K 2R1
  Canada
  http://info.usherbrooke.ca/llavoie/
  [CC BY-4.0 (http://creativecommons.org/licenses/by/4.0)]

Tâches projetées :
2018-09-19 (LL) : Compléter les insertions
  * Compléter au fur et à mesure de l'élaboration du schéma.

Tâches réalisées :
2013-09-03 (LL) : Création de cas de tests minimaux
  * un test minimal

Références :
[eno] http://info.usherbrooke.ca/llavoie/enseignement/Exemples/ReflexD/ReflexD_DDV.pdf
-- -----------------------------------------------------------------------------
-- fin de Insertion_neg.sql
-- =========================================================================== Z
*/
