-- 1- CENTRE SPECIALISE N'A QU UN SPORT
create function verifiespecialise()
  returns trigger
language plpgsql
as $$
BEGIN
IF (SELECT distinct  count(idSport) as nbSport
From estPratique p join centresportif c2 on p.idcentre = c2.idcentre
WHERE polyvalent = false
GROUP BY p.idCentre)>=1
THEN RAISE EXCEPTION 'un centre specialise ne peut abriter plus d un sport';
ELSE
RETURN NEW;
END IF;
END;
$$;

CREATE TRIGGER check_Centre_nbSport 
BEFORE INSERT OR UPDATE ON estPratique
FOR EACH ROW EXECUTE PROCEDURE VerifieSpecialise();




--2- On verifie que le nbre max de terrains n'est pas depass� -
create function verifienbterrain()
  returns trigger
language plpgsql
as $$
BEGIN
IF EXISTS (select  idCentre, NBTerrain, count (terrain.idTerrain)
    from CentreSportif join Terrain using(idcentre)
    group by idCentre
    Having count (terrain.idTerrain) >= NBTerrain
    )
THEN RAISE EXCEPTION 'le nombre de terrain inserer depasse le nombre de terrains maximum au centre';
ELSE
RETURN NEW;
END IF;
END;
$$;

CREATE TRIGGER check_insertion_terrains
BEFORE INSERT OR UPDATE ON Terrain
FOR EACH ROW EXECUTE PROCEDURE Verifienbterrain();


--3-- le sexe doit �tre le m�me dans l'attribution du vestiaire et le sexe vestiaire

CREATE FUNCTION VerifieSexevestiaire()
RETURNS TRIGGER AS
$$
BEGIN

IF EXISTS (
SELECT vestiaire.sexe  , AttribueVestiaire.sexevestiaire , idvestiaire
FROM vestiaire join AttribueVestiaire using(idvestiaire)
WHERE sexe != sexevestiaire
)
THEN  RAISE EXCEPTION 'VOUS AVEZ ATTRIBUÉ UN MAUVAIS VESTIAIRE ( PROBLEME DE SEXE) ! ';
ELSE
RETURN NEW;
END IF;
END;
$$
LANGUAGE plpgsql;

CREATE TRIGGER check_sexeVestiaire
AFTER INSERT OR UPDATE ON AttribueVestiaire
FOR EACH ROW EXECUTE PROCEDURE VerifieSexevestiaire();


--4-- le terrain � reserver doit �tre disponible


CREATE FUNCTION VerifieT()
RETURNS TRIGGER AS
$$
BEGIN
IF  EXISTS (

SELECT idTerrain , disponible
FROM reservation join Terrain using(idCentre,idTerrain)
WHERE disponible = false
)
THEN  RAISE EXCEPTION 'ce terrain nest pas disponible' ;
ELSE
RETURN NEW;
END IF;

END;
$$
LANGUAGE plpgsql ;

CREATE TRIGGER check_terrain_Dispo
AFTER INSERT OR UPDATE ON reservation
FOR EACH ROW EXECUTE PROCEDURE VerifieT();


--8- L EQUIPEMENT DISPONIBLE 


CREATE FUNCTION VerifieEQUIPEMENT()
RETURNS TRIGGER AS
$$
BEGIN
IF EXISTS
(

SELECT idEquipement , disponible
FROM attribueEquipement join equipement using(idCentre,idEquipement)
WHERE disponible = false

)
THEN  RAISE EXCEPTION 'cet equipement nest pas disponible' ;
ELSE
RETURN NEW;
END IF;
END;
$$
LANGUAGE plpgsql ;

CREATE TRIGGER check_eq_dispo
AFTER INSERT OR UPDATE ON attribueEquipement
FOR EACH ROW EXECUTE PROCEDURE VerifieEQUIPEMENT();


--9- LE VESTIAIRE DISPONIBLE


CREATE FUNCTION VerifieVestiaire()
RETURNS TRIGGER AS
$$
BEGIN
IF EXISTS
(

SELECT idVestiaire , disponible
FROM attribueVestiaire join vestiaire using(idCentre,idVestiaire)
WHERE disponible = false

)
THEN  RAISE EXCEPTION 'CE VESTIAIRE N EST PAS  DISPONIBLE !' ;
ELSE
RETURN NEW;
END IF;
END;
$$
LANGUAGE plpgsql ;

CREATE TRIGGER check_vestiaire_dispo
AFTER INSERT OR UPDATE ON attribueVestiaire
FOR EACH ROW EXECUTE PROCEDURE VerifieVestiaire();


--10- - le sport pratiqu� dans le terrain doit �tre le m�me que celui de l'equipement reservee.


CREATE FUNCTION VerifisportEquipement ()
RETURNS TRIGGER AS
$$
BEGIN
IF EXISTS
(
  SELECT idequipement, TypeEquipement.nom, TypeEquipement.idSport, reservation.idsport
  from TypeEquipement
  join equipement using(idTypeEquipement)
  join AttribueEquipement using (idEquipement,idCentre)
  join Reservation using (idReservation)
  WHERE TypeEquipement.idSport !=  reservation.idsport
)

THEN RAISE EXCEPTION 'equipement reserver doit appartenir au meme sport pratique dans le terrain'  ;
ELSE
RETURN NEW;
END IF;
END;
$$
LANGUAGE plpgsql;

CREATE TRIGGER check_SportEquipement
AFTER INSERT OR UPDATE ON AttribueEquipement
FOR EACH ROW EXECUTE PROCEDURE VerifisportEquipement();


/*
CONTRAINTES SUR LES DATES 

LA PERIDODE DE RESERVATION DES EQUIPEMENTS ET DES VESTIAIRES DOIT ETRE COMPRISE DNS LA PERIODE DE RESERVATION DU VESTIAIRE 

LA PERIODE DE L EVENEMENT DOIT ETRE PLUS GRANDE QUE CELLE DE LA RESERVATION 

LA DATE DE PAYEMENT DOIT ETRE INFERIEUR A CELLE DU DEBUT DE L'EVENEMENT 


*/


