drop table accueille cascade;
drop table payement cascade;
drop table prix cascade;
drop table attribueequipement cascade;
drop table attribuevestiaire cascade;
drop table estpratique cascade;
drop table reservation cascade;
drop table sport cascade;
drop table vestiaire cascade;
drop table terrain cascade;
drop table Evenement cascade;
drop table client cascade;
drop table equipement cascade;
drop table centresportif cascade;
drop table TypeEquipement cascade;

-- suppression des domaines

drop type idcentre_domaine cascade ;
drop type idreservation_domaine cascade;
drop type idclient_domaine cascade;
drop type idEvenement_domaine cascade;
drop type idequipement_domaine cascade;
drop type idTypeEquipement_domaine cascade;
drop type idsport_domaine cascade;
drop type idterrain_domaine cascade;
drop type idvestiaire_domaine cascade;
drop type text_court_domaine cascade;
drop type text_long_domaine cascade;
drop type typereservation_domaine cascade;
drop type sexe_domaine cascade;



drop function verifienbTerrain() cascade;
drop function verifiespecialise() cascade;
drop function VerifieSexevestiaire() cascade;
drop function VerifieT() cascade;
drop function VerifieEQUIPEMENT() cascade;
drop function VerifieVestiaire() cascade;
drop function VerifisportEquipement() cascade;
