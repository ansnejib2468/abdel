
--Création des domaines:=====================================================================================================

--Domaine : texte court
CREATE DOMAIN text_court_domaine
VARCHAR(60) NOT NULL
CONSTRAINT textcourt_mustexist CHECK (LENGTH(VALUE) > 0);

--Domaine : texte long
CREATE DOMAIN text_long_domaine
VARCHAR(500) NOT NULL
CONSTRAINT textlong_mustexist CHECK (LENGTH(VALUE) > 0);

--Domaine : idClient
CREATE DOMAIN idclient_domaine
CHAR(8) NOT NULL
CONSTRAINT idclient_format CHECK(VALUE SIMILAR TO 'CL[0-9]{6}');

--Domaine : idCentre
CREATE DOMAIN idCentre_domaine
CHAR(8) NOT NULL
CONSTRAINT idcentre_format CHECK(VALUE SIMILAR TO 'CSP[0-9]{5}');

--Domaine : idSport
CREATE DOMAIN idSport_domaine
CHAR(6) NOT NULL
CONSTRAINT idsport_format CHECK(VALUE SIMILAR TO 'SPT[0-9]{3}');

--Domaine : idTerrain
CREATE DOMAIN idTerrain_domaine
CHAR(6) NOT NULL
CONSTRAINT idTerrain_format CHECK(VALUE SIMILAR TO 'TR[0-9]{4}');

--Domaine : idEquipement
CREATE DOMAIN idEquipement_domaine
CHAR(6) NOT NULL
CONSTRAINT idEquipement_format CHECK(VALUE SIMILAR TO 'EQ[0-9]{4}');

--Domaine : idVestiaire
CREATE DOMAIN idVestiaire_domaine
CHAR(6) NOT NULL
CONSTRAINT idVestiaire_format CHECK(VALUE SIMILAR TO 'VST[0-9]{3}');

--Domaine: typeReservation
CREATE DOMAIN typeReservation_domaine
VARCHAR(10) NOT NULL
CONSTRAINT typeReservation_format CHECK (VALUE IN ('AMICAL','TOURNOIS'));

--Domaine: idEvenement
CREATE DOMAIN idEvenement_domaine
VARCHAR(8) NOT NULL
CONSTRAINT idEvenement_format CHECK(VALUE SIMILAR TO 'E[0-9]{7}');

--Domaine: idReservation
CREATE DOMAIN idReservation_domaine
VARCHAR(8) NOT NULL
CONSTRAINT idReservation_format CHECK(VALUE SIMILAR TO 'RZ[0-9]{6}');

--Domaine : idTypeEquipement
CREATE DOMAIN idTypeEquipement_domaine
CHAR(6) NOT NULL
CONSTRAINT idTypeEquipement_format CHECK(VALUE SIMILAR TO 'TE[0-9]{4}');

--Domaine: Sexe
CREATE DOMAIN Sexe_domaine
CHAR(1) NOT NULL
CONSTRAINT Sexe_format CHECK (VALUE IN ('M','F'));




---------------------------- Création des tables -------------------------------

-- Table Client
create table IF NOT EXISTS client
(
 idClient idclient_domaine   NOT NULL,
 Nom text_court_domaine      NOT NULL,
 Prenom text_court_domaine      NOT NULL,
 Sexe Sexe_domaine      NOT NULL,
 Adresse text_long_domaine NOT NULL,
 Courriel text_court_domaine  NOT NULL,
 Tel CHAR(10)                NOT NULL,

 CONSTRAINT client_cc0 PRIMARY KEY (idClient)

);


 -- Table Centre sportif
create table IF NOT EXISTS CentreSportif
(
   idCentre  idCentre_domaine    NOT NULL,
   Nom       text_court_domaine  NOT NULL,
   Polyvalent BOOLEAN            NOT NULL,
   NBTerrain        SMALLINT     NOT NULL,
   Adresse   text_court_domaine  NOT NULL,
   Courriel text_court_domaine   NOT NULL,
   Tel CHAR(10)                  NOT NULL,


   CONSTRAINT CentreSportif_cc0 PRIMARY KEY (idCentre)


 );


-- Table Sport

 create table IF NOT EXISTS Sport
(
  idSport idSport_domaine NOT NULL,
  Nom text_court_domaine NOT NULL,

  CONSTRAINT Sport_cc0 PRIMARY KEY (idSport)

 );



-- Table EstPratiqué

create table IF NOT EXISTS EstPratique
(
   idSport idSport_domaine NOT NULL,
   idCentre  idCentre_domaine    NOT NULL,

    CONSTRAINT EstPratique_cc0 PRIMARY KEY (idCentre,idSport),
    CONSTRAINT EstPratique_ce0 FOREIGN KEY (idCentre) REFERENCES CentreSportif,
    CONSTRAINT EstPratique_ce1 FOREIGN KEY (idSport) REFERENCES Sport
);



--  Table Terrain
create table IF NOT EXISTS Terrain
(
    idTerrain idTerrain_domaine NOT NULL,
	idCentre  idCentre_domaine  NOT NULL,
	Disponible BOOLEAN,
	CONSTRAINT Terrain_cc0 PRIMARY KEY (idTerrain,idCentre),
	CONSTRAINT Terrain_ce0 FOREIGN KEY (idCentre) REFERENCES CentreSportif

);


-- Table Accueille

create table IF NOT EXISTS Accueille
(
   idTerrain idTerrain_domaine NOT NULL,
   idCentre  idCentre_domaine  NOT NULL,
   idSport idSport_domaine NOT NULL,


  CONSTRAINT Accueille_cc0 PRIMARY KEY (idSport,idCentreid,Terrain),
  CONSTRAINT Accueille_ce0 FOREIGN KEY (idTerrain,idCentre) REFERENCES Terrain,
  CONSTRAINT Accueille_ce1 FOREIGN KEY (idSport,idCentre) REFERENCES EstPratique(idSport,idCentre)
);


-- Table TypeEquipement

create table IF NOT EXISTS TypeEquipement
(
 idTypeEquipement idTypeEquipement_domaine NOT NULL,
 idSport  idSport_domaine  NOT NULL,
 Nom text_court_domaine NOT NULL,


 CONSTRAINT TypeEquipement_cc0 PRIMARY KEY (idTypeEquipement),
 CONSTRAINT TypeEquipement_ce0 FOREIGN KEY (idSport) REFERENCES Sport

);

-- Table Equipement

create table IF NOT EXISTS Equipement
(
 idEquipement idEquipement_domaine NOT NULL,
 idCentre idCentre_domaine NOT NULL,
 idTypeEquipement idTypeEquipement_domaine NOT NULL,
 Disponible BOOLEAN NOT NULL,

 CONSTRAINT Equipement_cc0 PRIMARY KEY (idEquipement, idCentre),
 CONSTRAINT Equipement_ce0 FOREIGN KEY (idCentre) REFERENCES CentreSportif,
 CONSTRAINT Equipement_ce1 FOREIGN KEY (idTypeEquipement) REFERENCES TypeEquipement

);


-- Table Vestiaire

create table IF NOT EXISTS Vestiaire
(
   idVestiaire idVestiaire_domaine NOT NULL,
   idCentre  idCentre_domaine  NOT NULL,
   Sexe Sexe_domaine NOT NULL,
   Capacite  SMALLINT NOT NULL,
   Disponible BOOLEAN NOT NULL,

   CONSTRAINT Vestiaire_cc0 PRIMARY KEY (idVestiaire, idCentre),
   CONSTRAINT Vestiaire_ce0 FOREIGN KEY (idCentre) REFERENCES CentreSportif,
   CONSTRAINT Vestiaire_Capacite CHECK (capacite > 0)

);


 -- Table Evenement

create table IF NOT EXISTS Evenement
(
 idEvenement idEvenement_domaine NOT NULL,
 idClient idclient_domaine NOT NULL,
 debutEvenement TIMESTAMP NOT NULL,
 finEvenement TIMESTAMP NOT NULL,
 Description text_long_domaine NOT NULL,


 CONSTRAINT Evenement_cc0 PRIMARY KEY (idEvenement,idClient),
 CONSTRAINT Evenement_ce0 FOREIGN KEY (idClient) REFERENCES client


 );


-- Table Reservation

create table IF NOT EXISTS Reservation
(
 idReservation idReservation_domaine NOT NULL,
 idClient idclient_domaine NOT NULL,
 idEvenement idEvenement_domaine NOT NULL,
 debutReservation TIMESTAMP NOT NULL,
 finReservation TIMESTAMP NOT NULL,
 idTerrain idterrain_domaine NOT NULL,
 idCentre  idCentre_domaine  NOT NULL,
 idSport idSport_domaine NOT NULL,
 Date_Reservation Date NOT NULL,

 CONSTRAINT Reservation_cc0 PRIMARY KEY (idReservation),
 CONSTRAINT Reservation_ce1 FOREIGN KEY (idTerrain,idCentre,idSport) REFERENCES Accueille,
 CONSTRAINT Reservation_ce3 FOREIGN KEY (idEvenement,idClient) REFERENCES Evenement

 );






-- Table AttribueVestiaire

create table IF NOT EXISTS AttribueVestiaire
(
 idReservation idReservation_domaine NOT NULL,
 debutReservation TIMESTAMP NOT NULL,
 finReservation TIMESTAMP NOT NULL,
 idCentre  idCentre_domaine  NOT NULL,
 idVestiaire idVestiaire_domaine NOT NULL,
 DateRéservationV TIMESTAMP NOT NULL,
 sexeVestiaire Sexe_domaine NOT NULL,

 CONSTRAINT AttribueVestiaire_cc0 PRIMARY KEY (idReservation),
 CONSTRAINT AttribueVestiaire_ce0 FOREIGN KEY (idReservation) REFERENCES Reservation,
 CONSTRAINT AttribueVestiaire_ce1 FOREIGN KEY (idVestiaire, idCentre) REFERENCES Vestiaire

);



-- Table AttribueEquipement

create table IF NOT EXISTS AttribueEquipement
(
 idReservation idReservation_domaine NOT NULL,
 debutReservation TIMESTAMP NOT NULL,
 finReservation TIMESTAMP NOT NULL,
 idCentre  idCentre_domaine  NOT NULL,
 idEquipement idEquipement_domaine NOT NULL,
 DateRéservationE TIMESTAMP NOT NULL,


 CONSTRAINT AttribueEquipement_cc0 PRIMARY KEY (idReservation),
 CONSTRAINT AttribueEquipement_ce0 FOREIGN KEY (idReservation) REFERENCES Reservation,
 CONSTRAINT AttribueEquipement_ce1 FOREIGN KEY (idEquipement, idCentre) REFERENCES Equipement

);

-- Table Prix

create table IF NOT EXISTS prix
(
 idReservation idReservation_domaine NOT NULL,
 prixTotal        SMALLINT NOT NULL, 
 prixTerrain      SMALLINT NOT NULL, 
 prixEquipement   SMALLINT NOT NULL, 
 prixVestiaire    SMALLINT NOT NULL, 


 CONSTRAINT prix_cc0 PRIMARY KEY (idReservation,prixTotal),
 CONSTRAINT prix_ce0 FOREIGN KEY (idReservation) REFERENCES Reservation

);

-- Table Payement 
create table IF NOT EXISTS Payement 
(
 idReservation idReservation_domaine NOT NULL,
 idClient idclient_domaine NOT NULL,
 prixTotal        SMALLINT NOT NULL, 
 ModePayement     CHAR(10),
 Effectue         BOOLEAN, 
 DatePayement     DATE ,


 CONSTRAINT Payement_cc0 PRIMARY KEY (idClient,idReservation,prixTotal),
 CONSTRAINT Payement_ce0 FOREIGN KEY (idReservation,prixTotal) REFERENCES prix

);




