
/*Insertion des données dns la table Dimevenement*/
INSERT INTO DimEvenement (idevenement, Description)
SELECT idEvenement,Description
FROM Evenement ;

INSERT INTO DimClient ( idClient,nom,prenom,sexe,adresse,courriel,tel)
SELECT idClient,nom,prenom,sexe,adresse,courriel,tel
FROM client ;

INSERT INTO DimCentreSportif ( idCentre,nom,Polyvalent,NBTerrain,adresse,courriel,tel)
SELECT idCentre,nom,Polyvalent,NBTerrain,adresse,courriel,tel
FROM centresportif ;

INSERT INTO DimSport (idSport,Nom)
SELECT idSport,Nom
FROM SPORT ;

INSERT INTO DimTerrain (idTerrain,Disponible)
SELECT idTerrain,Disponible
FROM terrain ;

INSERT INTO DimEquipement (idTypeEquipement,Nom)
SELECT idTypeEquipement,nom
FROM typeequipement ;

INSERT INTO DimVestiaire (idVestiaire,Sexe,Capacite,Disponible)
SELECT idVestiaire,Sexe,Capacite,Disponible
FROM vestiaire ;


