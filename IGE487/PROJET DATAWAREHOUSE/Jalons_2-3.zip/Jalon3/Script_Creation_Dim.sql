



--Domaine: idMois
CREATE DOMAIN idMois_domaine
VARCHAR(10) NOT NULL
CONSTRAINT idMois_format CHECK(VALUE SIMILAR TO 'M[0-9]{3}');


--Domaine: Mois
CREATE DOMAIN Mois_Domaine
VARCHAR(20) NOT NULL
CONSTRAINT Mois_format CHECK (VALUE IN ('1','2','3', '4','5','6','7','8','9','10','11','12'));


--Domaine: idAnnee
CREATE DOMAIN idAnnee_Domaine
VARCHAR(10) NOT NULL
CONSTRAINT idAnnee_format CHECK(VALUE SIMILAR TO 'A[0-9]{3}');

--Domaine: idHeure
CREATE DOMAIN idHeure_Domaine
VARCHAR(10) NOT NULL
CONSTRAINT idHEURE_format CHECK(VALUE SIMILAR TO 'H[0-9]{3}');



---------------------------- Création des tables Dimension -------------------------------

-- Table DimClient
create table IF NOT EXISTS DimClient
(
 id_Dim_Client SERIAL NOT NULL,
 idClient idclient_domaine   NOT NULL,
 Nom text_court_domaine      NOT NULL,
 Prenom text_court_domaine      NOT NULL,
 Sexe Sexe_domaine      NOT NULL,
 Adresse text_long_domaine NOT NULL,
 Courriel text_court_domaine  NOT NULL,
 Tel CHAR(10)                NOT NULL,

 CONSTRAINT DimClient_cc0 PRIMARY KEY (id_Dim_Client)

);


 -- Table Dim Centre sportif
create table IF NOT EXISTS DimCentreSportif
(
   id_Dim_Centre SERIAL NOT NULL,
   idCentre  idCentre_domaine    NOT NULL,
   Nom       text_court_domaine  NOT NULL,
   Polyvalent BOOLEAN            NOT NULL,
   NBTerrain        SMALLINT     NOT NULL,
   Adresse   text_court_domaine  NOT NULL,
   Courriel text_court_domaine   NOT NULL,
   Tel CHAR(10)                  NOT NULL,


   CONSTRAINT DimCentreSportif_cc0 PRIMARY KEY (id_Dim_Centre)


 );


-- Table DimSport

 create table IF NOT EXISTS DimSport
(
  id_Dim_Sport SERIAL NOT NULL,
  idSport idSport_domaine NOT NULL,
  Nom text_court_domaine NOT NULL,

  CONSTRAINT DimSport_cc0 PRIMARY KEY (id_Dim_Sport)

 );



-- Table Dim Date

create table IF NOT EXISTS DimDate
(
   id_Dim_Date SERIAL NOT NULL,
   id_Mois  idMois_Domaine    NOT NULL,
   Jour text_court_domaine NOT NULL,

    CONSTRAINT DimDate_cc0 PRIMARY KEY (id_Dim_Date),
    CONSTRAINT DimDate_ce0 FOREIGN KEY (id_Mois) REFERENCES Mois

);
            --- Table Heure---

	create table IF NOT EXISTS Heure
(
   idHeure idHeure_Domaine NOT NULL,
   Heure TIME NOT NULL,


    CONSTRAINT Heure_cc0 PRIMARY KEY (idHeure)


);

             --- Table Annee---

	create table IF NOT EXISTS Annee
(
   idAnnee idAnnee_Domaine NOT NULL,
   Annee text_court_domaine NOT NULL,
   idHeure idHeure_Domaine   NOT NULL,


    CONSTRAINT Annee_cc0 PRIMARY KEY (idAnnee),
	CONSTRAINT Annee_ce0 FOREIGN KEY (idHeure) REFERENCES Heure


);

              --- Table Mois---
	
	create table IF NOT EXISTS Mois
(
   id_Mois idMois_Domaine NOT NULL,
   Mois Mois_Domaine NOT NULL,
   idAnnee idAnnee_Domaine    NOT NULL,
   

    CONSTRAINT Mois_cc0 PRIMARY KEY (id_Mois),
	CONSTRAINT Mois_ce0 FOREIGN KEY (idAnnee) REFERENCES Annee

    
);



 -- Table Dim Evenement

create table IF NOT EXISTS DimEvenement
(
 id_Dim_Evenement SERIAL NOT NULL,
 idEvenement idEvenement_domaine NOT NULL,
 Description text_long_domaine NOT NULL,


 CONSTRAINT DimEvenement_cc0 PRIMARY KEY (id_Dim_Evenement)
 );
 
 
 
--  Table DimTerrain
create table IF NOT EXISTS DimTerrain
(
    id_Dim_Terrain SERIAL NOT NULL,
	idTerrain idTerrain_domaine NOT NULL,
	Disponible BOOLEAN,
	CONSTRAINT DimTerrain_cc0 PRIMARY KEY (id_Dim_Terrain)

);




-- Table DimEquipement

create table IF NOT EXISTS DimEquipement
(
 id_Dim_Equipement SERIAL NOT NULL,
 idTypeEquipement idTypeEquipement_domaine NOT NULL,
 Nom text_court_domaine NOT NULL,


 CONSTRAINT DimEquipement_cc0 PRIMARY KEY (id_Dim_Equipement)

);




-- Table DimVestiaire

create table IF NOT EXISTS DimVestiaire
(
   id_Dim_Vestiaire SERIAL NOT NULL,
   idVestiaire idVestiaire_domaine NOT NULL,
   Sexe Sexe_domaine NOT NULL,
   Capacite  SMALLINT NOT NULL,
   Disponible BOOLEAN NOT NULL,

   CONSTRAINT DimVestiaire_cc0 PRIMARY KEY (id_Dim_Vestiaire)

);


---------------------------- Création des tables fait-------------------------------



-- Table Fait_Reservation_T

create table IF NOT EXISTS Fait_ReservationT
(
 id_Dim_Terrain SERIAL  NOT NULL,
 id_Dim_Client SERIAL  NOT NULL,
 id_Dim_Centre SERIAL  NOT NULL,
 id_Dim_DateDebut SERIAL  NOT NULL,
 id_Dim_DateFin SERIAL  NOT NULL,
 id_Dim_Sport SERIAL  NOT NULL,
 Nbre_Terrains INTEGER NOT NULL,
 Durée_Moyenne_T INTEGER NOT NULL,

 CONSTRAINT Fait_ReservationT_cc0 PRIMARY KEY (id_Dim_Terrain,id_Dim_Client,id_Dim_Centre,id_Dim_DateDebut,id_Dim_DateFin,id_Dim_Sport),
 CONSTRAINT Fait_ReservationT_ce1 FOREIGN KEY (id_Dim_Terrain) REFERENCES DimTerrain,
 CONSTRAINT Fait_ReservationT_ce2 FOREIGN KEY (id_Dim_Client) REFERENCES DimClient,
 CONSTRAINT Fait_ReservationT_ce3 FOREIGN KEY (id_Dim_Centre) REFERENCES DimCentreSportif,
 CONSTRAINT Fait_ReservationT_ce4 FOREIGN KEY (id_Dim_DateDebut) REFERENCES DimDate,
 CONSTRAINT Fait_ReservationT_ce5 FOREIGN KEY (id_Dim_DateFin) REFERENCES DimDate,
 CONSTRAINT Fait_ReservationT_ce6 FOREIGN KEY (id_Dim_Sport) REFERENCES DimSport



 );

-- Table Fait_Reservation_V

create table IF NOT EXISTS Fait_ReservationV
(
 id_Dim_Vestiaire SERIAL  NOT NULL,
 id_Dim_Client SERIAL  NOT NULL,
 id_Dim_Centre SERIAL  NOT NULL,
 id_Dim_DateDebut SERIAL  NOT NULL,
 id_Dim_DateFin SERIAL  NOT NULL,
 id_Dim_Sport SERIAL NOT NULL,
 Nbre_Vestiaire INTEGER NOT NULL,
 Durée_Moyenne_V INTEGER NOT NULL,

 CONSTRAINT Fait_ReservationV_cc0 PRIMARY KEY (id_Dim_Vestiaire,id_Dim_Client,id_Dim_Centre,id_Dim_DateDebut,id_Dim_DateFin,id_Dim_Sport),
 CONSTRAINT Fait_ReservationV_ce1 FOREIGN KEY (id_Dim_Vestiaire) REFERENCES DimVestiaire,
 CONSTRAINT Fait_ReservationV_ce2 FOREIGN KEY (id_Dim_Client) REFERENCES DimClient,
 CONSTRAINT Fait_ReservationV_ce3 FOREIGN KEY (id_Dim_Centre) REFERENCES DimCentreSportif,
 CONSTRAINT Fait_ReservationV_ce4 FOREIGN KEY (id_Dim_DateDebut) REFERENCES DimDate,
 CONSTRAINT Fait_ReservationV_ce5 FOREIGN KEY (id_Dim_DateFin) REFERENCES DimDate,
  CONSTRAINT Fait_ReservationV_ce6 FOREIGN KEY (id_Dim_Sport) REFERENCES DimSport

 );


-- Table Fait_Reservation_E

create table IF NOT EXISTS Fait_ReservationE
(
 id_Dim_Equipement SERIAL  NOT NULL,
 id_Dim_Client SERIAL  NOT NULL,
 id_Dim_Centre SERIAL  NOT NULL,
 id_Dim_DateDebut SERIAL  NOT NULL,
 id_Dim_DateFin SERIAL  NOT NULL,
 id_Dim_Sport SERIAL  NOT NULL,
 Nbre_Equipement INTEGER NOT NULL,
 Durée_Moyenne_Eq INTEGER NOT NULL,

 CONSTRAINT Fait_ReservationE_cc0 PRIMARY KEY (id_Dim_Equipement,id_Dim_Client,id_Dim_Centre,id_Dim_DateDebut,id_Dim_DateFin,id_Dim_Sport),
 CONSTRAINT Fait_ReservationE_ce1 FOREIGN KEY (id_Dim_Equipement) REFERENCES DimEquipement,
 CONSTRAINT Fait_ReservationE_ce2 FOREIGN KEY (id_Dim_Client) REFERENCES DimClient,
 CONSTRAINT Fait_ReservationE_ce3 FOREIGN KEY (id_Dim_Centre) REFERENCES DimCentreSportif,
 CONSTRAINT Fait_ReservationE_ce4 FOREIGN KEY (id_Dim_DateDebut) REFERENCES DimDate,
 CONSTRAINT Fait_ReservationE_ce5 FOREIGN KEY (id_Dim_DateFin) REFERENCES DimDate,
 CONSTRAINT Fait_ReservationE_ce6 FOREIGN KEY (id_Dim_Sport) REFERENCES DimSport



 );

-- Table Fait_Evenement

create table IF NOT EXISTS Fait_Evenement
(
 id_Dim_Evenement SERIAL  NOT NULL,
 id_Dim_Client SERIAL  NOT NULL,
 id_Dim_Centre SERIAL  NOT NULL,
 id_Dim_DateDebut SERIAL  NOT NULL,
 id_Dim_DateFin SERIAL  NOT NULL,
 id_Dim_Sport SERIAL  NOT NULL,
 Nbre_Evenement INTEGER NOT NULL,
 Durée_Moyenne_E INTEGER NOT NULL,

 CONSTRAINT Fait_Evenement_cc0 PRIMARY KEY (id_Dim_Evenement,id_Dim_Client,id_Dim_Centre,id_Dim_DateDebut,id_Dim_DateFin,id_Dim_Sport),
 CONSTRAINT Fait_Evenement_ce1 FOREIGN KEY (id_Dim_Evenement) REFERENCES DimEvenement,
 CONSTRAINT Fait_Evenement_ce2 FOREIGN KEY (id_Dim_Client) REFERENCES DimClient,
 CONSTRAINT Fait_Evenement_ce3 FOREIGN KEY (id_Dim_Centre) REFERENCES DimCentreSportif,
 CONSTRAINT Fait_Evenement_ce4 FOREIGN KEY (id_Dim_DateDebut) REFERENCES DimDate,
 CONSTRAINT Fait_Evenement_ce5 FOREIGN KEY (id_Dim_DateFin) REFERENCES DimDate,
 CONSTRAINT Fait_Evenement_ce6 FOREIGN KEY (id_Dim_Sport) REFERENCES DimSport



 );
