#ifdef __KERNEL__ 
# include <linux/slab.h>
#else
# define kmalloc(a,b) malloc(a)
# define kfree(a) free(a)
# define spin_lock(l)
# define spin_unlock(l)
# define spin_lock_irqsave(l, f)
# define spin_unlock_irqrestore(l, f)
# define ENOMEM 1
#endif

#include "cbuffer.h"

//IFT320 :   'cbuffer'  signifie  <Caracter Buffer>
//IFT320 : Codez le corps de toutes les fonctions d'acc�s au tampon circulaire.
//IFT320 : Vous devriez avoir inscrit la signature de ces fonctions dans le fichier 'cbuffer.h'
//IFT320 : <Initialiser>,<Enfiler>, <D�filer>, <EstVide>, etc.


// MODULE INITIALISER
void Initialiser(struct cbuffer* file, u8 taille){
	int i;
	file->tete=0;
	file->queue=0;
	file->taille=taille;
	file->vide=1;
	file->plein=0;
	file->buf=kmalloc(sizeof(char)*taille,GFP_KERNEL);
	for(i=0;i<taille;i++)
		file->buf[i]=0;
}

// MODULE ENFILER
int Enfiler(struct cbuffer* file, u8 elem){
	if ( !EstPlein(file) ){
		file->vide=0;
		file->buf[file->tete]=elem;
		file->tete=((file->tete)+1)%(file->taille);
		if (file->queue == file->tete)
			file->plein=1;
		return 0;
	}
	return 1;
  }

//MODULE DEFILER
u8 Defiler(struct cbuffer* file){
	u8 res=0;
	if (!EstVide(file)){
		file->plein=0;
		res=file->buf[file->queue];
		file->queue=((file->queue)+1)%(file->taille);
		if (file->queue == file->tete)
			file->vide=1;
	} 
	return res;
}

// MODULE ESTVIDE
u8 EstVide(struct cbuffer* file){
	return file->vide;
}

//MODULE ESTPLEIN
u8 EstPlein(struct cbuffer* file){
 	return file->plein;
}

//MODULE DESINITIALISER
void Desinitialiser(struct cbuffer* file){
  kfree(file->buf);
}

