/* 
 * Programme enfant pour tester Join. 
 * Ce test doit etre execute avec l'algorithme de planification FCFS.
 * Il est normalement demarre par JoinTest.
 */

#include "syscall.h"

int main()
{  
	Yield();
	Yield();
	Write("No.  No.  That's not true! That's impossible!\n",59,ConsoleOutput);
	
  	Exit(110);
    
}
