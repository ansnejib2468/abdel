/* 
 * Programme enfant pour tester Join. 
 * Ce test doit etre execute avec l'algorithme de planification FCFS.
 * Il est normalement demarre par JoinTest.
 */

#include "syscall.h"

int main()
{  
	
	Write("I'll never join you!\n",22,ConsoleOutput);
	
  	Exit(42);
    
}
