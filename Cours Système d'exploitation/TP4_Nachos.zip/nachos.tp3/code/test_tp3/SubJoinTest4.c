/* 
 * Programme enfant pour tester Join. 
 * Ce test doit etre execute avec l'algorithme de planification FCFS.
 * Il est normalement demarre par JoinTest.
 */

#include "syscall.h"

int main()
{  
	
	Write("No!  No!  No!",13,ConsoleOutput);
	
  	Exit(12);
    
}
