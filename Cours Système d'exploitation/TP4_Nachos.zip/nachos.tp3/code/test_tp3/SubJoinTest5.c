/* 
 * Programme enfant pour tester Join. 
 * Ce test doit etre execute avec l'algorithme de planification FCFS.
 * Il est normalement demarre par JoinTest.
 */

#include "syscall.h"

int main()
{  
	
	Write("...\n",5,ConsoleOutput);
	
  	Exit(9);
    
}
