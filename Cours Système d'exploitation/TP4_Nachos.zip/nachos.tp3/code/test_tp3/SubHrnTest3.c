

#include "syscall.h"

int
main()
{  	
	int i;
	for(i=0;i<20;i++){
		Write("5-Programme enfant 3\n",22,ConsoleOutput);	
	}	
  	Exit(0);
    
}
