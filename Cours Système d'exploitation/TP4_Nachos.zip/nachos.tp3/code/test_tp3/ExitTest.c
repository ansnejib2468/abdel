/* 
 * 	Test pour l'appel systeme Exit.
 */

#include "syscall.h"

int
main()
{	
	//Fin normale.
  	Exit(0);    
}
