// exception.cc 
//	Entry point into the Nachos kernel from user programs.
//	There are two kinds of things that can cause control to
//	transfer back to here from user code:
//
//	syscall -- The user code explicitly requests to call a procedure
//	in the Nachos kernel.  Right now, the only function we support is
//	"Halt".
//
//	exceptions -- The user code does something that the CPU can't handle.
//	For instance, accessing memory that doesn't exist, arithmetic errors,
//	etc.  
//
//	Interrupts (which can also cause control to transfer from user
//	code into the Nachos kernel) are handled elsewhere.
//
// For now, this only handles the Halt() system call.
// Everything else core dumps.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"
#include "syscall.h"


//IFT320: Quelques definitions utiles.

//Cette fonction est definie dans progtest.cc. Sera utile ici, wink-wink.
extern void StartProcess(char *filename);

//Union utilitaire pour travailler avec les mots provenant du mips simule.
//ReadMem a besoin d'un espace de 4 octets pour faire sa lecture (adresse de int).
//Cependant, on peut vouloir aller chercher chaque octet du groupe de 4 individuellement.
union Word32{
 int intVal;
 char charVal[4];
};


#define VirtualAddress int
#define KernelAddress char*
#define MAX_FILENAME_LENGTH 100


//Mise a jour du compteur ordinal du mips simule.
//Doit etre fait avant de terminer ExceptionHandler, si on veut que le processus qui a
//lance l'exception continue normalement. 
void incrementPC();

void starproc(int nomExecutable); 
//IFT320: Declarations de fonctions pour les appels systeme.
//Ces fonctions seront appelees par ExceptionHandler.
//L'ordre dans lequel sont presentees les declarations est l'ordre dans lequel
//il vous est suggere d'implanter les fonctions.

//Ce qui appellera ces fonction est ExceptionHandler, definie plus bas. C'est la routine
//d'interruption pour l'instruction SysCall, ainsi que toutes les erreurs de programmes.
//Allez la lire, MAINTENANT.


//1-Exit, parametre = code de sortie de fin du programme (0 signale un deroulement normal).
//Verifiable avec la commande texit
void SysCallExit(int code);

//2-CopyFromUser, taille connue. Recupere les donnees dans l'espace d'adresses du processus. 
//processus ----> Noyau
void CopyFromUser(VirtualAddress userBufferSource, KernelAddress kernelBufferDestination,int size);

//3-Log Write. Ecriture dans le journal noyau (DEBUG 'l'), utile pour les algorithmes de planification.
//Verifiable avec la commande tlog
void SysCallLogWrite(VirtualAddress userBufferSource, int size);

//4-CopyFromUser, taille inconnue. Recupere une chaine de caracteres dans l'espace d'adresses du processus
//processus ----> Noyau
void CopyFromUser(VirtualAddress userBufferSource, KernelAddress kernelBufferDestination);

//5-Create, creation de fichier via fileSystem->Create. VERSION FILESYS_STUB!!
//Verifiable avec la commande tcreate
void SysCallCreate(VirtualAddress fileName);

//6-Open, ouverture de fichier via fileSystem->Open. VERSION FILESYS_STUB!! Pas de table de fichiers ouverts.
OpenFileId SysCallOpen(VirtualAddress fileName);

//7-Write, ecriture dans un fichier via Openfile->write.
//Verifiable avec la commande twrite
void SysCallWrite(OpenFileId fileDestination,VirtualAddress userBufferSource, int size);

//8-CopyToUser, taille connue. Ecrit copie les donnees du noyau vers le processus.
//Noyau ----> processus
void CopyToUser(KernelAddress kernelBufferSource,VirtualAddress userBufferDestination,int size);

//9-Read, lecture dans un fichier via Openfile->read.
//Verifiable avec la commande tread
//Verifiable avec la commande treadwrite
void SysCallRead(OpenFileId fileSource,VirtualAddress userBufferDestination, int size);

//10-Exec, ouverture d'un executable et chargement d'un processus dans un nouvel espace d'adresses
//Verifiable avec la commande texec
SpaceId SysCallExec(VirtualAddress executableName,int initialPriority);

//11- ALLEZ FAIRE UN TOUR DANS ADDRSPACE.
//L'heure a sonne d'apprendre comment les programmes sont charges dans le mips simule.

//12- Yield, permet a un processus de lacher volontairement l'UCT et de retourner dans la file
//des processus prets. Utile pour verifier que vous avez effectivement reussi a charger plusieurs
//programmes dans la memoire du mips simule.
//Verifiable avec les commandes tspace, tyield et tfull
void SysCallYield();

//13-Join, attente de la fin d'un processus. Le processus qui demande le Join recoit le code de sortie
//du processus enfant pour lequel il demande Join.
//Verifiable avec les commandes tminijoin et tjoin
int SysCallJoin(SpaceId id);

//14-C'est le moment d'aller faire les algorithmes de planification!
//Allez faire un tour dans Thread, Scheduler et Main.
//Les algorithmes sont testables avec les commandes suivantes:
//	FCFS: texec, tyield, tspace, tminijoin, tjoin
//  Round-Robin: trobin
//	Priorite statique: tprio
//  HRN: thrn


//----->>> Par ici les amis, on sert des Nachos jusqu'a 4h du matin dans cette fonction.
//----------------------------------------------------------------------
// ExceptionHandler
// 	Entry point into the Nachos kernel.  Called when a user program
//	is executing, and either does a syscall, or generates an addressing
//	or arithmetic exception.
//
// 	For system calls, the following is the calling convention:
//
// 	system call code -- r2
//		arg1 -- r4
//		arg2 -- r5
//		arg3 -- r6
//		arg4 -- r7
//
//	The result of the system call, if any, must be put back into r2. 
//
// And don't forget to increment the pc before returning. (Or else you'll
// loop making the same system call forever!)
//
//	"which" is the kind of exception.  The list of possible exceptions 
//	is in machine.h.
//----------------------------------------------------------------------

void ExceptionHandler(ExceptionType which)
{
	VirtualAddress name;
	VirtualAddress userbuffer;
	int size;
	OpenFileId handle;
	int initialPriority;
	SpaceId spaceId; 
	
	
    if (which == SyscallException) {

		int type = machine->ReadRegister(2);
		
		switch(type){
			
			case SC_Halt:
				printf("Shutdown, initiated by user program.\n");
				interrupt->Halt();
				
			case SC_Exit: 				 
				SysCallExit(machine->ReadRegister(4)); 
				break; 
				
			case SC_Write: 			
				userbuffer = machine->ReadRegister(4); 
				size = machine->ReadRegister(5);  
				handle = machine->ReadRegister(6);
				SysCallWrite(handle,userbuffer,size); 
			break; 
			
			case SC_Create: 	
				name=machine->ReadRegister(4); 		
				SysCallCreate(name);
			break; 
				
			case SC_Open: 
				name=machine->ReadRegister(4);				
				SysCallOpen(name); 
			break;		
				
			case SC_Read:
				userbuffer = machine->ReadRegister(4); 
				size = machine->ReadRegister(5);  
				handle = machine->ReadRegister(6);				
				SysCallRead(handle,userbuffer,size); 
			break; 
				
			case SC_Exec: 
				name = machine->ReadRegister(4); 					
				initialPriority = machine->ReadRegister(5); 
				SysCallExec(name,initialPriority); 								
			break; 	
				
			case SC_Yield: 
				SysCallYield(); 			
			break; 								
							
			case SC_Join:
			
				spaceId= machine->ReadRegister(4); 
				SysCallJoin(spaceId); 
			break;  				
								
			default:				
				printf("Unrecognized Syscall type: %d.\n",type);				
				ASSERT(FALSE);
		}		
    } 

	//0-Traitement des erreurs de programme. 
	//C'est ici que vous avez ENFIN le plaisir de dispenser des Segmentation Fault
	//aux processus pleins de bugs.
	//Verifiable avec la commande terror
	
	else	{		
		switch (which){
			case PageFaultException: 
				printf("PageFault Exception!\n");
				break;  
			case ReadOnlyException: 
				printf("ReadOnly Exception!\n");
				break;  
			case BusErrorException: 
				printf("BusError Exception!\n");
				break;  	
			case AddressErrorException: 
				printf("Address Erro rException!\n");
				break; 	
			case OverflowException: 
				printf("Overflow Exception!\n");
				break; 		
			
			case IllegalInstrException: 
				printf("IllegalInstrException!\n");
				break; 				
			case NoException: 
				printf("No Exception!\n");
				break; 	
	}	 
	}
	incrementPC(); 
}


void incrementPC(){

	int pc;
	
	pc=machine->ReadRegister(PCReg);
	machine->WriteRegister(PrevPCReg,pc);
	pc = machine->ReadRegister(NextPCReg);
	machine->WriteRegister(PCReg,pc);
	pc+=4;
	machine->WriteRegister(NextPCReg,pc);
}


void SysCallExit(int code){
	
	printf("Exit!");		 
	currentThread->setFin(code); 	
	currentThread->Finish();	
}


void CopyFromUser(VirtualAddress userBufferSource, KernelAddress kernelBufferDestination,int size)
{	
	union Word32 value; 
		 
	for (int i=0;i<size;++i)
	{
		machine->ReadMem(userBufferSource+i,1,&value.intVal);
		kernelBufferDestination[i]=value.intVal;
	}
}


void SysCallLogWrite(VirtualAddress userBufferSource, int size){
	char* textAecrire=new char[size];  
	CopyFromUser(userBufferSource,textAecrire,size);
	
	for (int i=0;i<size;++i)
	{
		DEBUG('l', "%c", textAecrire[i]);
	}	
	DEBUG('l', "\n");
}


void CopyFromUser(VirtualAddress userBufferSource, KernelAddress kernelBufferDestination){
	int i=0; 
	int value=-1; 
	while(value!=0){
		machine->ReadMem(userBufferSource+i,1,&value);
		kernelBufferDestination[i]=value;
		++i; 
	}
}


void SysCallCreate(VirtualAddress fileName){
	char* nomFichier=new char[MAX_FILENAME_LENGTH]; 
	CopyFromUser(fileName,nomFichier); 	
	fileSystem->Create(nomFichier,0); 
	//printf(" Creation du fichier: %s. \n ",nomFichier); 
}


OpenFileId SysCallOpen(VirtualAddress fileName){
	char* nomFichier=new char[MAX_FILENAME_LENGTH]; 
	CopyFromUser(fileName,nomFichier); 	
	if (strlen(nomFichier)==0){
		printf("On ne peut pas ouvrir le fichier %s ! \n",nomFichier); 
		return -1; 
	}
	else {
		OpenFile * openFile = fileSystem->Open(nomFichier); 
		int index = int(openFile);
		//Mettre le resultat de l appel system dans le registre 2
		machine->WriteRegister(2,index);		
		return index;
	}
}


void SysCallWrite(OpenFileId fileDestination,VirtualAddress userBufferSource, int size){		
	
	if (fileDestination==ConsoleOutput)
	{
		SysCallLogWrite(userBufferSource,size);  
	}
	else
	{
		char* textAecrire=new char[size];  
		CopyFromUser(userBufferSource,textAecrire,size);		
		OpenFile * openFile = (OpenFile *)fileDestination; 
		openFile->Write(textAecrire,size); 
	}	
}


void CopyToUser(KernelAddress kernelBufferSource,VirtualAddress userBufferDestination,int size){
		
	int value=0; 
	
	for (int i=0;i<size;++i)
	{
		value=kernelBufferSource[i]; 
		machine->WriteMem(userBufferDestination+i,1,value);
	}
}


void SysCallRead(OpenFileId fileSource,VirtualAddress userBufferDestination, int size){
		
	char* textAlire=new char[size]; 
	OpenFile * openFile = (OpenFile *)fileSource; 	
	openFile->Read(textAlire,size); 	
	CopyToUser(textAlire,userBufferDestination,size); 
}

void starproc(int nomExecutable)
{
	StartProcess((char*)nomExecutable); 
}

SpaceId SysCallExec(VirtualAddress executableName,int initialPriority){
	
	char* nomExecutable = new char[100];  
	
	CopyFromUser(executableName,nomExecutable); 	
	
	Thread* thread = new Thread(nomExecutable); 
	thread->setPriority(initialPriority); 	
	
	thread->addParent(currentThread);
	currentThread->addEnfant(thread);
	
	thread->Fork(starproc,int(nomExecutable)); 	
			
	machine->WriteRegister(2, (SpaceId)thread);

	return (SpaceId)thread;
}

void SysCallYield(){
	currentThread->Yield(); 
}

int SysCallJoin(SpaceId id){
	Thread * thread = (Thread *) id;	
	currentThread->Join(id); 
	machine->WriteRegister(2,thread->getCode());		
	return thread->getCode(); 
}
