

#include "syscall.h"

int
main()
{  	
	int i;
	for(i=0;i<20;i++){
		Write("3-Programme enfant 1\n",22,ConsoleOutput);	
	}	
  	Exit(0);
    
}
