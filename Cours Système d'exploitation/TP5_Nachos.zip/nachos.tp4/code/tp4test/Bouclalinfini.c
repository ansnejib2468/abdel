/* 
 * Programme enfant demarre par ExecTest.
 * Est assez grand pour causer des problemes s'il est mal charge en memoire.
 * Son affichage devrait se faire exclusivement apres ceux du parent.
 */

#include "syscall.h"

int
main()
{  	
	
	Write("4-Boucle infinie, demarrage\n",52,ConsoleOutput);	
		
	while(1){
		
	}	
  	Exit(0);
    
}
