/* 
 * Programme enfant pour tester Join. 
 * Ce test doit etre execute avec l'algorithme de planification FCFS.
 * Il est normalement demarre par MiniJoinTest.
 */

#include "syscall.h"

int main()
{  
	
	Write("Enfant\n",8,ConsoleOutput);
	
  	Exit(99);
    
}
