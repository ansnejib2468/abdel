
#include "syscall.h"

int
main()
{  	
	int i;
	for(i=0;i<20;i++){
		Write("4-Programme enfant 2\n",22,ConsoleOutput);	
	}	
  	Exit(0);
    
}
