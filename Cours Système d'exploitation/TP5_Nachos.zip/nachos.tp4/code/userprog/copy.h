void CopyFromUser(char * dest, char * source, int longueur);

void CopyToUser(char * dest, char * source, int longueur);
